let str = 'Before you build a complete application';

function wordsFromString (str){
    let arr = str.split('');

    console.log(arr);
}
wordsFromString(str);

