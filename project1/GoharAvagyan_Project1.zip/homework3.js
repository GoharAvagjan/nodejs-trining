/*
3. Modules պապակայում ստեղծել currentTime մոդուլ currentTime ֆունկցիայով որը արտածում է  կանչելու պահին ժամը, րոպեն ,վարկյանը և միլիվայրկյանը :
Մոդուլը ներմուծել homework3.js ֆայլում և կանչել currentTime ֆունկցիավ  ու արդյունքը արտածել console-ում:
 */
const time = require('./Modules/currentTime');

console.log(time());
