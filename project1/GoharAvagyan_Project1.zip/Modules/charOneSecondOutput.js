const word = 'Laura'

function charOneSecondOutput (){
    const arr = word.split('');
    arr.forEach(element => {console.log(element)});
}

setTimeout(charOneSecondOutput, 1000);
module.exports = charOneSecondOutput;
