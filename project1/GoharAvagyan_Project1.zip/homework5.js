/*
    5.Modules պապակայում ստեղծել charOneSecondOutput մոդուլ charOneSecondOutput ֆունկցիայով որը console-ում  արտածում է ֆունկցիային տրված բառի տառերը 1 վայրկյան պարբերությամբ:
    Մոդուլը ներմուծել homework5.js ֆայլում և charOneSecondOutput ֆունկցիա կանչել Ձեր անուն ազգանունից  կազմված բառակապակցության համար :
 */

const charOneSecondOutput = require('./Modules/charOneSecondOutput');
console.log(charOneSecondOutput);
