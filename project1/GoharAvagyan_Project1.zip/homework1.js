/*
1. Ստեղծել homework1.js ֆայլ որը աշխատեցնելուց հետո __filename գլոբալի  միջոցով console-ում
    արտածել ֆայլի բացարձակ ճանապարը և  ճանապարհի անվան երկարությունը
 */
console.log(__filename);
console.log(__filename.length);

